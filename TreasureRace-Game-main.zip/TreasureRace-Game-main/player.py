import pygame
from config import *
import random
from Astar import a_star_pathfinding

class Player:
    def __init__(self, x, y, is_human=True):
        self.x = x
        self.y = y
        self.score = 0
        self.is_human = is_human

        self.is_frozen = False
        self.frozen_moves_left = 0
        self.freeze_used = False

    def move(self, dx, dy):
        if self.is_frozen:
            return

        new_x = self.x + dx
        new_y = self.y + dy

        if 0 <= new_x < GRID_SIZE and 0 <= new_y < GRID_SIZE:
            self.x = new_x
            self.y = new_y
    
    def use_freeze(self):
        if not self.freeze_used:
            self.freeze_used = True
            return True
        return False

    def apply_freeze(self):
        self.is_frozen = True
        self.frozen_moves_left = 5

    def change_score(self, points):
        self.score = max(0, self.score + points)

    def can_freeze(self):
        return not self.freeze_used and not self.is_frozen

    def draw(self, screen):
        rect = pygame.Rect(self.x * CELL_SIZE, self.y * CELL_SIZE, CELL_SIZE, CELL_SIZE)
        pygame.draw.rect(screen, self.color, rect)
        if self.frozen_timer > 0:
            # Draw a frozen indicator
            pygame.draw.circle(screen, (173, 216, 230), rect.center, CELL_SIZE // 3)

    def is_freeze_ready(self, current_turn):
        return current_turn - self.last_freeze_turn >= self.freeze_cooldown

class AIPlayer(Player):
    def __init__(self, x, y, color):
        super().__init__(x, y, False)
        self.path = []
        self.treasures_left = True

    def find_nearest_treasure(self, board):
        if not self.treasures_left:
            return None

        treasures = []
        for r_idx, row in enumerate(board.grid):
            for c_idx, cell in enumerate(row):
                if isinstance(cell, dict) and cell['type'] == 'treasure':
                    treasures.append((c_idx, r_idx))
        
        if not treasures:
            self.treasures_left = False
            return None

        treasures.sort(key=lambda t: abs(t[0] - self.x) + abs(t[1] - self.y))
        return treasures[0]

    def update_path(self, board):
        target = self.find_nearest_treasure(board)
        if target:
            path = a_star_pathfinding((self.x, self.y), target, board.grid)
            if path and len(path) > 1:
                self.path = path[1:] # Exclude the current position
            else:
                self.path = []

    def move_ai(self, board):
        if self.frozen_timer > 0:
            return

        if not self.path:
            self.update_path(board)
        
        if self.path:
            next_pos = self.path.pop(0)
            self.x = next_pos[0]
            self.y = next_pos[1]
        else: # No path, move randomly
            self.move_randomly()

    def move_randomly(self):
        dx, dy = random.choice([(0, 1), (0, -1), (1, 0), (-1, 0)])
        self.move(dx, dy) 