import pygame
import math
from config import *

# Colors from Tailwind config
GRAY_900 = (17, 24, 39)
GRAY_800 = (31, 41, 55)
GRAY_700 = (55, 65, 81)
GRAY_600 = (75, 85, 99)
GRAY_300 = (209, 213, 219)
WHITE = (255, 255, 255)
YELLOW_400 = (250, 204, 21)
BLUE_400 = (96, 165, 250)
BLUE_600 = (37, 99, 235)
BLUE_700 = (29, 78, 216)
GREEN_400 = (74, 222, 128)
GREEN_600 = (22, 163, 74)
PURPLE_600 = (147, 51, 234)
PURPLE_700 = (126, 34, 206)
PURPLE_900_T = (76, 29, 149, 200) # Transparent for bg
PURPLE_400 = (192, 132, 252)
CYAN_600 = (8, 145, 178)
CYAN_700 = (14, 116, 144)
CYAN_300 = (103, 232, 249)
RED_400 = (248, 113, 113)
RED_500 = (239, 68, 68)
RED_700 = (185, 28, 28)
YELLOW_600 = (202, 138, 4)
ORANGE_400 = (251, 146, 60)
ORANGE_600 = (234, 88, 12)

P1_COLOR = BLUE_400
P2_COLOR = GREEN_400
TRAP_COLOR = RED_500

# Initialize pygame font system and define all fonts
pygame.font.init()
DEFAULT_FONT = "Segoe UI"  

# Try to load an emoji-capable font
EMOJI_FONT = None
try:
    # Try common emoji fonts on different platforms
    emoji_font_names = [
        "Segoe UI Emoji",  # Windows
        "Apple Color Emoji",  # macOS
        "Noto Color Emoji",  # Linux
        "Segoe UI Symbol",  # Windows fallback
        "Arial Unicode MS",  # Cross-platform fallback
    ]
    
    for font_name in emoji_font_names:
        try:
            EMOJI_FONT = pygame.font.SysFont(font_name, 18)
            if EMOJI_FONT:
                break
        except:
            continue
    
    # If no emoji font found, fall back to default
    if not EMOJI_FONT:
        EMOJI_FONT = pygame.font.SysFont(DEFAULT_FONT, 18)
        
except Exception as e:
    print(f"Warning: Could not load emoji font: {e}")
    EMOJI_FONT = pygame.font.SysFont(DEFAULT_FONT, 18)

TITLE_FONT = pygame.font.Font(None, 74)
HEADER_FONT = pygame.font.SysFont(DEFAULT_FONT, 30)
SUBHEADER_FONT = pygame.font.SysFont(DEFAULT_FONT, 22)
TEXT_FONT = pygame.font.SysFont(DEFAULT_FONT, 18)
SCORE_FONT = pygame.font.SysFont(DEFAULT_FONT, 24)
BUTTON_FONT = pygame.font.SysFont(DEFAULT_FONT,18)
SMALL_FONT = pygame.font.SysFont(DEFAULT_FONT, 16)

class ScrollState:
    def __init__(self, scroll_speed=25):
        self.scroll_y = 0
        self.content_height = 0
        self.view_height = 0
        self.scroll_speed = scroll_speed

    def handle_event(self, event):
        if event.type == pygame.MOUSEWHEEL:
            self.scroll_y -= event.y * self.scroll_speed
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_UP:
                self.scroll_y -= self.scroll_speed
            elif event.key == pygame.K_DOWN:
                self.scroll_y += self.scroll_speed

    def clamp(self):
        max_scroll = max(0, self.content_height - self.view_height)
        self.scroll_y = max(0, min(self.scroll_y, max_scroll))

instructions_scroll_state = ScrollState()

# Asset Loading
ui_assets = {}
assets_loaded = False
def load_ui_assets():
    global assets_loaded
    try:
        # Maps internal asset name to filename and size
        icon_map = {
            'trophy': ('trophy.png', (26, 26)),
            'user': ('user-round.png', (20, 20)),
            'bot': ('bot.png', (20, 20)),
            'user2': ('user-round_blue.png', (24, 24)),
            'bot2': ('bot_green.png', (24, 24)),
            'snowflake': ('snowflake.png', (17, 17)),
            'gem': ('gem.png', (24, 24)),
            'zap': ('zap.png', (24, 24)),
            'gem2': ('gem_yellow.png', (24, 24)),
            'zap2': ('zap_red.png', (24, 24))
        }
        for name, (filename, size) in icon_map.items():
            ui_assets[name] = pygame.transform.scale(pygame.image.load(f'assets/{filename}').convert_alpha(), size)
        assets_loaded = True
    except (pygame.error, FileNotFoundError) as e:
        print(f"Warning: Could not load some UI assets. Some icons will be missing. Error: {e}")
        assets_loaded = False

def draw_text(surface, text, font, color, pos, align="midleft", bold=False):
    font.set_bold(bold)
    text_surf = font.render(str(text), True, color)
    font.set_bold(False)
    text_rect = text_surf.get_rect()
    setattr(text_rect, align, pos)
    surface.blit(text_surf, text_rect)

def draw_gradient_rect(surface, rect, start_color, end_color, border_radius):
    clip_rect = rect.copy()
    gradient_surf = pygame.Surface(rect.size, pygame.SRCALPHA)
    start_col, end_col = pygame.Color(start_color), pygame.Color(end_color)
    for x in range(rect.width):
        blend = x / rect.width
        color = start_col.lerp(end_col, blend)
        pygame.draw.line(gradient_surf, color, (x, 0), (x, rect.height))
    mask_surf = pygame.Surface(rect.size, pygame.SRCALPHA)
    pygame.draw.rect(mask_surf, (255, 255, 255, 255), (0, 0, rect.width, rect.height), border_radius=border_radius)
    gradient_surf.blit(mask_surf, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)
    surface.blit(gradient_surf, rect.topleft)

def draw_progress_bar(surface, rect, progress, grad_start, grad_end):
    pygame.draw.rect(surface, GRAY_700, rect, border_radius=rect.height // 2)
    if progress > 0:
        progress = min(1.0, progress)
        
        # Create a surface for the full-width gradient bar
        grad_surf = pygame.Surface(rect.size, pygame.SRCALPHA)
        
        # Draw the rounded gradient on it
        draw_gradient_rect(grad_surf, pygame.Rect(0, 0, rect.width, rect.height), grad_start, grad_end, rect.height // 2)
        
        # Blit only the portion of the gradient needed for the progress
        progress_width = int(rect.width * progress)
        surface.blit(grad_surf, rect.topleft, pygame.Rect(0, 0, progress_width, rect.height))

def draw_background(surface):
    width, height = surface.get_size()
    c1, c2 = GRAY_900, PURPLE_900_T
    for y in range(height):
        blend = y / height
        color = pygame.Color(c1).lerp(c2, math.sin(blend * math.pi))
        pygame.draw.line(surface, color, (0, y), (width, y))

def draw_main_layout(surface):
    width, height = surface.get_size()
    sidebar_width = max(350, width // 3.5)
    board_area_width = width - sidebar_width - 30
    
    board_rect = pygame.Rect(15, 100, board_area_width, height - 100)
    sidebar_rect = pygame.Rect(board_area_width + 30, 100, sidebar_width, height - 100)
    
    draw_text(surface, "Treasure Race", TITLE_FONT, YELLOW_400, (width/2, 40), align="center")
    draw_text(surface, "Compete to collect treasures and reach 100 points first!", SMALL_FONT, GRAY_300, (width/2, 80), align="center")
    
    return board_rect, sidebar_rect

def draw_scoreboard(surface, rect, p1, p2, turn_count, p1_visual_score, p2_visual_score, game_status, buttons, mouse_pos):
    # Match the exact same outer dimensions as Card 1 and Card 2
    content_rect = rect.inflate(-20, -10)  # Same as game_controls
    
    # Calculate the actual content height needed with moderate spacing
    header_height = 40  # Back to reasonable size
    player_section_height = 35  # Each player name + score
    progress_bar_height = 12
    spacing_header_to_p1 = 15  # Reduced from 25 to keep it cohesive
    spacing_p1_to_bar = 12    # Reduced from 20 to keep player info and bar connected
    spacing_between_players = 18  # Reduced from 25 to maintain flow
    spacing_p2_to_bar = 12    # Reduced from 20 to keep player info and bar connected
    
    # Total content height needed with moderate spacing
    needed_height = (header_height + 
                    spacing_header_to_p1 +
                    player_section_height + spacing_p1_to_bar + progress_bar_height +  # P1 section
                    spacing_between_players + 
                    player_section_height + spacing_p2_to_bar + progress_bar_height +  # P2 section
                    30)  # Increased bottom padding from 12 to 16 for proper breathing room
    
    # Allow the scoreboard to be taller if needed
    actual_height = min(needed_height + 10, rect.height)  # Small buffer
    
    # Shift the entire scoreboard down to better center it in the sidebar
    vertical_offset = 25  # Move the whole scoreboard down by 25px
    scoreboard_rect = pygame.Rect(content_rect.left, rect.top + vertical_offset, content_rect.width, actual_height)
    
    pygame.draw.rect(surface, GRAY_900, scoreboard_rect, border_radius=16)
    
    # Use consistent padding with the game controls cards
    padding = 18  # Moderate padding for breathing room without excess
    inner_content_rect = scoreboard_rect.inflate(-padding*2, -padding*2)
    
    header_y = inner_content_rect.top
    if assets_loaded and 'trophy' in ui_assets:
        surface.blit(ui_assets['trophy'], (inner_content_rect.left, header_y))
    draw_text(surface, "Race to 100 Points", HEADER_FONT, WHITE, (inner_content_rect.left + 30, header_y + 12))
    
    p1_y = header_y + header_height + spacing_header_to_p1  # Moderate spacing from header
    if assets_loaded and 'user2' in ui_assets:
        surface.blit(ui_assets['user2'], (inner_content_rect.left, p1_y))
    draw_text(surface, "You", TEXT_FONT, WHITE, (inner_content_rect.left + 28, p1_y + 10))
    
    freeze_btn = buttons['freeze_ai']
    freeze_btn.size = (115, 28)  # Increased width from 95 to 110 to accommodate icon + text
    freeze_btn.topright = (inner_content_rect.right, p1_y)

    # Show freeze moves text at button position when frozen, or show button when can freeze
    if p1.is_frozen:
        # Position freeze moves text exactly where the button would be
        if assets_loaded and 'snowflake' in ui_assets:
            angle = (pygame.time.get_ticks() / 10) % 360
            rotated_icon = pygame.transform.rotate(ui_assets['snowflake'], angle)
            icon_rect = rotated_icon.get_rect(midleft=(freeze_btn.left + 6, freeze_btn.centery))
            surface.blit(rotated_icon, icon_rect)
        draw_text(surface, f"frozen:{p1.frozen_moves_left} moves", SMALL_FONT, CYAN_300, (freeze_btn.left + 25, freeze_btn.centery), align="midleft")
        # Score position when frozen (no button shown)
        draw_text(surface, p1.score, SCORE_FONT, BLUE_400, (freeze_btn.left - 15, p1_y + 12), align="midright")
    elif p1.can_freeze() and not p2.is_frozen:
        # Show freeze button
        is_hovered = freeze_btn.collidepoint(mouse_pos)
        freeze_btn_color = CYAN_700 if is_hovered else CYAN_600
        pygame.draw.rect(surface, freeze_btn_color, freeze_btn, border_radius=8)
        if assets_loaded and 'snowflake' in ui_assets:
            # Position icon with proper spacing from left edge
            icon_x = freeze_btn.left + 6
            icon_y = freeze_btn.centery - ui_assets['snowflake'].get_height() // 2
            surface.blit(ui_assets['snowflake'], (icon_x, icon_y))
            # Position text with proper spacing from icon and aligned with icon center
            text_x = icon_x + ui_assets['snowflake'].get_width() + 4
            # Calculate the icon's vertical center and align text to it
            icon_center_y = icon_y + ui_assets['snowflake'].get_height() // 2
            draw_text(surface, "Freeze AI", BUTTON_FONT, WHITE, (text_x, icon_center_y), align="midleft", bold=True)
        else:
            draw_text(surface, "Freeze AI", BUTTON_FONT, WHITE, freeze_btn.center, align="center", bold=True)
        # Score position when button is shown
        draw_text(surface, p1.score, SCORE_FONT, BLUE_400, (freeze_btn.left - 15, p1_y + 12), align="midright")
    else:
        # No button and not frozen - score takes full width
        draw_text(surface, p1.score, SCORE_FONT, BLUE_400, (inner_content_rect.right, p1_y + 12), align="midright")

    p1_bar_y = p1_y + player_section_height + spacing_p1_to_bar  # Closer spacing to keep it connected
    p1_bar_rect = pygame.Rect(inner_content_rect.left, p1_bar_y, inner_content_rect.width, 12)
    draw_progress_bar(surface, p1_bar_rect, p1_visual_score / WINNING_SCORE, BLUE_400, BLUE_600)

    p2_y = p1_bar_y + progress_bar_height + spacing_between_players  # Moderate spacing between sections
    if assets_loaded and 'bot2' in ui_assets:
        surface.blit(ui_assets['bot2'], (inner_content_rect.left, p2_y))
    draw_text(surface, "AI Player", TEXT_FONT, WHITE, (inner_content_rect.left + 28, p2_y + 10))
    
    # Visual "Freeze You" button for AI player (non-interactive)
    ai_freeze_btn = pygame.Rect(0, 0, 115, 28)
    ai_freeze_btn.topright = (inner_content_rect.right, p2_y)
    
    # Show freeze moves text at button position when frozen, or show button when can freeze
    if p2.is_frozen:
        # Position freeze moves text exactly where the button would be
        if assets_loaded and 'snowflake' in ui_assets:
            angle = (pygame.time.get_ticks() / 10) % 360
            rotated_icon = pygame.transform.rotate(ui_assets['snowflake'], angle)
            icon_rect = rotated_icon.get_rect(midleft=(ai_freeze_btn.left + 6, ai_freeze_btn.centery))
            surface.blit(rotated_icon, icon_rect)
        draw_text(surface, f"frozen:{p2.frozen_moves_left} moves", SMALL_FONT, CYAN_300, (ai_freeze_btn.left + 25, ai_freeze_btn.centery), align="midleft")
        # Score position when frozen (no button shown)
        draw_text(surface, p2.score, SCORE_FONT, GREEN_400, (ai_freeze_btn.left - 15, p2_y + 12), align="midright")
    elif p2.can_freeze() and not p1.is_frozen:
        # Show AI freeze button (visual only)
        ai_freeze_btn_color = CYAN_600  # Match the player's freeze button color
        pygame.draw.rect(surface, ai_freeze_btn_color, ai_freeze_btn, border_radius=8)
        if assets_loaded and 'snowflake' in ui_assets:
            # Position icon with proper spacing from left edge
            icon_x = ai_freeze_btn.left + 6
            icon_y = ai_freeze_btn.centery - ui_assets['snowflake'].get_height() // 2
            surface.blit(ui_assets['snowflake'], (icon_x, icon_y))
            # Position text with proper spacing from icon and aligned with icon center
            text_x = icon_x + ui_assets['snowflake'].get_width() + 4
            # Calculate the icon's vertical center and align text to it
            icon_center_y = icon_y + ui_assets['snowflake'].get_height() // 2
            draw_text(surface, "Freeze You", BUTTON_FONT, WHITE, (text_x, icon_center_y), align="midleft", bold=True)
        else:
            draw_text(surface, "Freeze You", BUTTON_FONT, WHITE, ai_freeze_btn.center, align="center", bold=True)
        # Score position when button is shown
        draw_text(surface, p2.score, SCORE_FONT, GREEN_400, (ai_freeze_btn.left - 15, p2_y + 12), align="midright")
    else:
        # No button and not frozen - score takes full width
        draw_text(surface, p2.score, SCORE_FONT, GREEN_400, (inner_content_rect.right, p2_y + 12), align="midright")

    p2_bar_y = p2_y + player_section_height + spacing_p2_to_bar  # Closer spacing to keep it connected
    p2_bar_rect = pygame.Rect(inner_content_rect.left, p2_bar_y, inner_content_rect.width, 12)
    draw_progress_bar(surface, p2_bar_rect, p2_visual_score / WINNING_SCORE, GREEN_400, GREEN_600)

def draw_text_with_emoji(surface, text, font, emoji_font, color, pos, align="midleft", bold=False):
    """Draw text with emoji support by using a separate emoji font for emoji characters."""
    font.set_bold(bold)
    
    # Check if text contains emojis (basic check for common emoji ranges)
    has_emoji = any(ord(char) > 127 for char in text)
    
    if has_emoji:
        # Use emoji font for text that contains emojis
        text_surf = emoji_font.render(str(text), True, color)
    else:
        # Use regular font for normal text
        text_surf = font.render(str(text), True, color)
    
    font.set_bold(False)
    text_rect = text_surf.get_rect()
    setattr(text_rect, align, pos)
    surface.blit(text_surf, text_rect)

def draw_game_controls(surface, rect, buttons, mouse_pos, game_status='playing'):
    # Shift the content area upward to use the space freed by the tighter scoreboard
    content_rect = rect.inflate(-20, -10)
    content_rect.y -= 30  # Move up by 15px to fill the gap
    
    # Increase Game Rules section height by reducing button section
    card1_h = 85  # Reduced from 100 to give more space to rules
    total_content_height = content_rect.height
    card2_h = total_content_height - card1_h - 15

    card1_rect = pygame.Rect(content_rect.left, content_rect.top, content_rect.width, card1_h)
    card2_rect = pygame.Rect(content_rect.left, card1_rect.bottom + 10, content_rect.width, card2_h)

    # Card 1: Buttons (adjusted for smaller height)
    pygame.draw.rect(surface, GRAY_900, card1_rect, border_radius=16, width=0)
    pygame.draw.rect(surface, GRAY_700, card1_rect, border_radius=16, width=1)
    
    # Re-calculate button positions to fit inside smaller card1
    padding = 8  # Reduced padding
    btn_content_rect = card1_rect.inflate(-padding*2, -padding*2)
    
    new_game_h = 32  # Reduced button height
    small_btn_h = btn_content_rect.height - new_game_h - padding
    
    # This check prevents negative heights if card1 is too small
    if small_btn_h > 0:
        # 'New Game' button
        buttons['new_game'].x = btn_content_rect.x
        buttons['new_game'].y = btn_content_rect.y
        buttons['new_game'].width = btn_content_rect.width
        buttons['new_game'].height = new_game_h
        
        # Smaller buttons below - now just Pause/Resume and Instructions
        small_btn_y = btn_content_rect.y + new_game_h + padding
        gap = 8  # Reduced gap
        small_btn_w = (btn_content_rect.width - gap) / 2

        buttons['pause_resume'].x = btn_content_rect.x
        buttons['pause_resume'].y = small_btn_y
        buttons['pause_resume'].width = small_btn_w
        buttons['pause_resume'].height = small_btn_h

        buttons['instructions'].x = btn_content_rect.x + small_btn_w + gap
        buttons['instructions'].y = small_btn_y
        buttons['instructions'].width = small_btn_w
        buttons['instructions'].height = small_btn_h

    button_list = ['new_game', 'pause_resume', 'instructions']
    for name in button_list:
        btn_rect = buttons[name]
        is_hovered = btn_rect.collidepoint(mouse_pos)
        
        if name == 'new_game':
            color = PURPLE_700 if is_hovered else PURPLE_600
        elif name == 'pause_resume':
            color = GRAY_800 if is_hovered else GRAY_700
        else:  # instructions
            color = GRAY_800 if is_hovered else GRAY_700
        
        pygame.draw.rect(surface, color, btn_rect, border_radius=8)
        
        # Handle button text and icons
        if name == 'pause_resume':
            button_text = 'Resume' if game_status == 'paused' else 'Pause'
            draw_text(surface, button_text, TEXT_FONT, WHITE, btn_rect.center, align="center", bold=True)
        elif assets_loaded and name.replace('_', '-') in ui_assets:
            icon = ui_assets[name.replace('_', '-')]
            surface.blit(icon, (btn_rect.x + 15, btn_rect.centery - icon.get_height()//2))
            draw_text(surface, name.replace('_', ' ').title(), TEXT_FONT, WHITE, (btn_rect.centerx + 10, btn_rect.centery), align="center", bold=True)
        else:
            display_text = name.replace('_', ' ').title()
            draw_text(surface, display_text, TEXT_FONT, WHITE, btn_rect.center, align="center", bold=True)

    # Card 2: Game Rules - Fixed alignment and text wrapping
    pygame.draw.rect(surface, GRAY_900, card2_rect, border_radius=16, width=0)
    pygame.draw.rect(surface, GRAY_700, card2_rect, border_radius=16, width=1)
    
    rules_content = card2_rect.inflate(-12, -12)  # Moderate padding
    
    # Draw title
    draw_text(surface, "Game Rules", TEXT_FONT, WHITE, (rules_content.left, rules_content.top + 3), align="topleft", bold=True)
    
    rules = [
        ("🎮", " Controls: Arrow keys, F to freeze, Space to pause"),
        ("💎", " Treasures: +5, +10, +15 points"),
        ("⚡", " Traps: -10 points"),
        ("❄️", " Freeze: Stop opponent for 5 turns"),
    ]

    # Start drawing rules below the title
    y_offset = rules_content.top + TEXT_FONT.get_height() + 10
    
    # Calculate proper line height that accounts for both emoji and text
    text_height = SMALL_FONT.get_height()
    emoji_height = EMOJI_FONT.get_height()
    base_line_height = max(text_height, emoji_height) + 3  # Add padding
    
    # Calculate available space
    available_height = rules_content.height - TEXT_FONT.get_height() - 10
    
    for i, (emoji, text) in enumerate(rules):
        # Calculate max width for text wrapping (subtract space for emoji and gap)
        max_text_width = rules_content.width - 30  # 24 for emoji space + 6 for gap
        
        # Wrap the text
        wrapped_lines = wrap_text(text, SMALL_FONT, max_text_width)
        
        # Calculate total height needed for this rule (including wrapped lines)
        rule_height = len(wrapped_lines) * text_height + (len(wrapped_lines) - 1) * 2  # 2px between lines
        total_rule_height = max(rule_height, emoji_height)
        
        # Make sure we don't go past the bottom
        if y_offset + total_rule_height > rules_content.bottom - 3:
            break
        
        emoji_x = rules_content.left
        text_x = emoji_x + 24  # Space for emoji + gap
        
        # Calculate vertical centering for emoji to align with the first line of text
        first_line_center_y = y_offset + text_height // 2
        emoji_y = first_line_center_y - emoji_height // 2
        
        # Draw emoji with proper vertical alignment to text baseline
        draw_text_with_emoji(surface, emoji, EMOJI_FONT, EMOJI_FONT, WHITE, (emoji_x, emoji_y), align="topleft")
        
        # Draw each wrapped line of text
        for line_idx, line in enumerate(wrapped_lines):
            line_y = y_offset + line_idx * (text_height + 2)
            draw_text(surface, line, SMALL_FONT, GRAY_300, (text_x, line_y), align="topleft")
        
        # Move to next rule
        y_offset += total_rule_height + 8  # 8px spacing between rules

def draw_game_over(surface, winner, p1_score, p2_score, buttons, mouse_pos):
    overlay = pygame.Surface(surface.get_size(), pygame.SRCALPHA)
    overlay.fill((0, 0, 0, 180))
    surface.blit(overlay, (0,0))
    
    card_rect = pygame.Rect(0, 0, 450, 450)
    card_rect.center = surface.get_rect().center
    pygame.draw.rect(surface, GRAY_900, card_rect, border_radius=16)
    pygame.draw.rect(surface, GRAY_700, card_rect, border_radius=16, width=1)
    
    content_rect = card_rect.inflate(-60, -60)
    is_player_winner = winner == 'Player 1'
    
    if assets_loaded and is_player_winner and 'trophy' in ui_assets:
        icon = ui_assets['trophy']
        icon_rect = icon.get_rect(midtop=(card_rect.centerx, content_rect.top))
        surface.blit(icon, icon_rect)

    y_offset = content_rect.top + 80
    win_text = 'Victory!' if is_player_winner else 'Game Over'
    draw_text(surface, win_text, TITLE_FONT, WHITE, (card_rect.centerx, y_offset), align="center")
    
    y_offset += 50
    sub_text = 'You won the treasure race!' if is_player_winner else 'The AI won this round.'
    draw_text(surface, sub_text, TEXT_FONT, GRAY_300, (card_rect.centerx, y_offset), align="center")

    y_offset += 50
    score_box = pygame.Rect(content_rect.left, y_offset, content_rect.width, 100)
    pygame.draw.rect(surface, GRAY_800, score_box, border_radius=8)
    draw_text(surface, "Final Scores", TEXT_FONT, WHITE, (score_box.centerx, score_box.top + 20), align="center")
    
    draw_text(surface, "You", TEXT_FONT, BLUE_400, (score_box.left + 30, score_box.bottom - 30))
    draw_text(surface, p1_score, SCORE_FONT, BLUE_400, (score_box.right - 30, score_box.bottom - 28), align="midright", bold=True)
    draw_text(surface, "AI Player", TEXT_FONT, GREEN_400, (score_box.left + 30, score_box.bottom - 60))
    draw_text(surface, p2_score, SCORE_FONT, GREEN_400, (score_box.right - 30, score_box.bottom - 58), align="midright", bold=True)
    
    # Position buttons at the bottom of the card
    btn_h_go = 50
    btn_y = content_rect.bottom - btn_h_go

    buttons['game_over_restart'].y = btn_y
    buttons['game_over_end_game'].y = btn_y

    for name in ['game_over_restart', 'game_over_end_game']:
        btn_rect = buttons[name]
        is_hovered = btn_rect.collidepoint(mouse_pos)
        text = "Restart" if name == 'game_over_restart' else "End Game"
        
        color = PURPLE_700 if is_hovered else PURPLE_600
        if name == 'game_over_end_game':
            color = GRAY_800 if is_hovered else GRAY_700
        
        pygame.draw.rect(surface, color, btn_rect, border_radius=8)
        draw_text(surface, text, TEXT_FONT, WHITE, btn_rect.center, align="center", bold=True)

def wrap_text(text, font, max_width):
    """Wrap text to fit within max_width, returning list of lines."""
    words = text.split(' ')
    lines = []
    current_line = ""
    
    for word in words:
        test_line = current_line + (" " if current_line else "") + word
        if font.size(test_line)[0] <= max_width:
            current_line = test_line
        else:
            if current_line:
                lines.append(current_line)
            current_line = word
    
    if current_line:
        lines.append(current_line)
    
    return lines

def draw_instructions(surface, buttons, mouse_pos):
    overlay = pygame.Surface(surface.get_size(), pygame.SRCALPHA)
    overlay.fill((0, 0, 0, 200))
    surface.blit(overlay, (0,0))

    card_rect = pygame.Rect(0, 0, 650, 600)
    card_rect.center = surface.get_rect().center
    pygame.draw.rect(surface, GRAY_900, card_rect, border_radius=16)
    
    # --- Header (Fixed) ---
    header_h = 60
    header_rect = pygame.Rect(card_rect.left, card_rect.top, card_rect.width, header_h)
    if assets_loaded and 'info_large' in ui_assets:
        icon = ui_assets['info_large']
        surface.blit(icon, (header_rect.x + 20, header_rect.centery - icon.get_height()//2))
    draw_text(surface, "Treasure Race - Instructions", HEADER_FONT, WHITE, (header_rect.x + 55, header_rect.centery), align="midleft", bold=True)

    close_btn = buttons['instructions_close']
    if assets_loaded and 'x' in ui_assets:
        surface.blit(ui_assets['x'], close_btn.topleft)

    # --- Footer (Fixed) ---
    footer_h = 80
    footer_rect = pygame.Rect(card_rect.left, card_rect.bottom - footer_h, card_rect.width, footer_h)
    pygame.draw.rect(surface, GRAY_900, footer_rect, 0, 0, 0, 16, 16)
    pygame.draw.line(surface, GRAY_700, footer_rect.topleft, footer_rect.topright, 1)

    got_it_btn = buttons['instructions_got_it']
    got_it_btn.size = (200, 45)
    got_it_btn.center = footer_rect.center
    is_hovered = got_it_btn.collidepoint(mouse_pos)
    color = PURPLE_700 if is_hovered else PURPLE_600
    pygame.draw.rect(surface, color, got_it_btn, border_radius=8)
    draw_text(surface, "Got it! Let's Play", TEXT_FONT, WHITE, got_it_btn.center, align="center", bold=True)

    # --- Scrollable Content Area ---
    content_view_rect = pygame.Rect(card_rect.x, header_rect.bottom, card_rect.width, card_rect.height - header_h - footer_h)
    
    instructions_scroll_state.view_height = content_view_rect.height

    content_surface_h = instructions_scroll_state.content_height or 2000 # Guess height if not calculated yet
    content_surface = pygame.Surface((content_view_rect.width, content_surface_h), pygame.SRCALPHA)
    
    y_offset = 20
    scroll_content_x = 30 # Padding inside the scrollable surface
    max_width = content_view_rect.width - 2 * scroll_content_x  # Set max width for text wrapping
    
    sections = [
        ("🎯", "Objective", ["Be the first player to reach 100 points by collecting treasures and avoiding traps!"]),
        ("🎮", "How to Play", [
            "• Use Arrow Keys to move your character around the board",
            "• Press F to freeze your opponent for 5 turns",
            "• Press Space to pause/resume the game",
            "• Collect treasures to gain points",
            "• Avoid traps that will cost you points",
            "• Compete against the AI player who uses smart pathfinding",
            "• Click anywhere on the board to pause/resume the game"
        ]),
        ("🧩", "Board Elements", [
            ("user2", "You (Human Player)", "Controlled with arrow keys", BLUE_400),
            ("bot2", "AI Player", "Uses smart pathfinding", GREEN_400),
            ("gem2", "Treasures", "Worth +5, +10, or +15 points", YELLOW_400),
            ("zap2", "Traps", "Cost you -10 points", RED_400),
        ]),
        ("✨", "Special Abilities", [
            ("❄️", "Freeze Power", "Each player can freeze their opponent once every 5 turns.", CYAN_300),
            "• Frozen players cannot move for 5 turns.",
            "• Use strategically to block opponent from valuable treasures.",
            "• AI can also freeze you, so watch out!",
        ]),
        ("ℹ️", "Game Rules", [
            "• If both players land on the same cell, both lose 5 points.",
            "• Treasures disappear once collected.",
            "• New treasures and traps appear randomly during the game.",
            "• The game ends immediately when someone reaches 100 points.",
            "• Scores can go negative if you hit too many traps.",
        ]),
        ("💡", "Pro Tips", [
            "• Higher value treasures (purple gems) are worth more points.",
            "• Plan your moves to avoid traps while collecting treasures.",
            "• Save your freeze ability for critical moments.",
            "• Watch the AI's movements to predict its next target.",
        ])
    ]
    
    for icon_name, title, content in sections:
        header_h = SUBHEADER_FONT.get_height()
        text_x = scroll_content_x
        
        # Use emoji for section headers instead of assets
        if any(ord(char) > 127 for char in icon_name):  # Check if it's an emoji
            draw_text_with_emoji(content_surface, icon_name, SUBHEADER_FONT, EMOJI_FONT, WHITE, (scroll_content_x, y_offset + header_h // 2), align="midleft")
            text_x += 30  # Space for emoji
        elif assets_loaded and icon_name in ui_assets:
            icon = ui_assets[icon_name]
            icon_y = y_offset + (header_h - icon.get_height()) // 2
            content_surface.blit(icon, (scroll_content_x, icon_y))
            text_x += icon.get_width() + 12
        
        draw_text(content_surface, title, SUBHEADER_FONT, WHITE, (text_x, y_offset + header_h // 2), align="midleft", bold=True)
        y_offset += header_h + 10
        
        if title == "Board Elements":
            items = content
            gap = 16
            content_width = content_view_rect.width - 2 * scroll_content_x
            card_width = (content_width - gap) // 2
            card_height = 75

            grid_start_y = y_offset
            num_rows = (len(items) + 1) // 2

            for i, item_data in enumerate(items):
                row, col = divmod(i, 2)
                card_x = scroll_content_x + col * (card_width + gap)
                card_y = grid_start_y + row * (card_height + gap)

                item_rect = pygame.Rect(card_x, card_y, card_width, card_height)
                pygame.draw.rect(content_surface, GRAY_800, item_rect, border_radius=8)

                icon_name, item_title, item_desc, color = item_data
                
                icon = ui_assets.get(icon_name) if assets_loaded else None
                icon_width = icon.get_width() if icon else 0
                
                icon_x = item_rect.x + 15
                if icon:
                    icon_y = item_rect.centery - icon.get_height() // 2
                    content_surface.blit(icon, (icon_x, icon_y))

                text_x = icon_x + icon_width + (10 if icon else 0)
                
                title_y = item_rect.y + 18
                desc_y = item_rect.y + 42
                
                # Wrap the title and description
                title_max_width = max_width - 35
                title_lines = wrap_text(item_title, TEXT_FONT, title_max_width)
                desc_lines = wrap_text(item_desc, SMALL_FONT, title_max_width)
                
                for i, line in enumerate(title_lines):
                    draw_text(content_surface, line, TEXT_FONT, color, (text_x, title_y + i * (TEXT_FONT.get_height() + 2)), align="topleft", bold=True)
                
                y_offset += len(title_lines) * (TEXT_FONT.get_height() + 2) + 5
                
                for i, line in enumerate(desc_lines):
                    draw_text(content_surface, line, SMALL_FONT, GRAY_300, (text_x, desc_y + i * (SMALL_FONT.get_height() + 2)), align="topleft")
                
                y_offset += len(desc_lines) * (SMALL_FONT.get_height() + 2) + 10
            
            y_offset = grid_start_y + num_rows * (card_height + gap)
        else:
            for item in content:
                item_x_offset = scroll_content_x + 15
                if isinstance(item, tuple): # Icon entry (like Freeze Power)
                    icon_name, item_title, item_desc, color = item
                    text_x = item_x_offset + 35
                    
                    # Check if icon_name is an emoji
                    if any(ord(char) > 127 for char in icon_name):
                        draw_text_with_emoji(content_surface, icon_name, TEXT_FONT, EMOJI_FONT, color, (item_x_offset, y_offset + 5), align="topleft")
                    elif assets_loaded and icon_name in ui_assets:
                        icon = ui_assets[icon_name]
                        content_surface.blit(icon, (item_x_offset, y_offset + 5))
                    
                    # Wrap the title and description
                    title_max_width = max_width - 50
                    title_lines = wrap_text(item_title, TEXT_FONT, title_max_width)
                    desc_lines = wrap_text(item_desc, SMALL_FONT, title_max_width)
                    
                    for i, line in enumerate(title_lines):
                        draw_text(content_surface, line, TEXT_FONT, color, (text_x, y_offset + i * (TEXT_FONT.get_height() + 2)), align="topleft", bold=True)
                    
                    y_offset += len(title_lines) * (TEXT_FONT.get_height() + 2) + 5
                    
                    for i, line in enumerate(desc_lines):
                        draw_text(content_surface, line, SMALL_FONT, GRAY_300, (text_x, y_offset + i * (SMALL_FONT.get_height() + 2)), align="topleft")
                    
                    y_offset += len(desc_lines) * (SMALL_FONT.get_height() + 2) + 10
                else:
                    # Wrap regular text items
                    text_max_width = max_width - 15
                    lines = wrap_text(item, TEXT_FONT, text_max_width)
                    
                    for i, line in enumerate(lines):
                        draw_text(content_surface, line, TEXT_FONT, GRAY_300, (item_x_offset, y_offset + i * (TEXT_FONT.get_height() + 2)), align="topleft")
                    
                    y_offset += len(lines) * (TEXT_FONT.get_height() + 2) + 5
        y_offset += 20
    
    instructions_scroll_state.content_height = y_offset
    instructions_scroll_state.clamp()
    
    source_area = pygame.Rect(0, instructions_scroll_state.scroll_y, content_view_rect.width, content_view_rect.height)
    surface.blit(content_surface, content_view_rect.topleft, source_area)

    max_scroll = instructions_scroll_state.content_height - instructions_scroll_state.view_height
    if max_scroll > 0:
        scrollbar_bg_rect = pygame.Rect(content_view_rect.right - 15, content_view_rect.top + 5, 8, content_view_rect.height - 10)
        pygame.draw.rect(surface, GRAY_800, scrollbar_bg_rect, border_radius=4)
        
        handle_h = max(20, content_view_rect.height * (content_view_rect.height / instructions_scroll_state.content_height))
        scroll_ratio = instructions_scroll_state.scroll_y / max_scroll if max_scroll > 0 else 0
        handle_y = scrollbar_bg_rect.y + scroll_ratio * (scrollbar_bg_rect.height - handle_h)
        
        handle_rect = pygame.Rect(scrollbar_bg_rect.x, handle_y, scrollbar_bg_rect.width, handle_h)
        pygame.draw.rect(surface, GRAY_600, handle_rect, border_radius=4)

def draw_gradient_text(surface, text, font, color1, color2, rect):
    text_render = font.render(text, True, color1)
    text_rect = text_render.get_rect(center=rect.center)
    
    # Create a gradient surface
    gradient = pygame.Surface((text_rect.width, text_rect.height), pygame.SRCALPHA)
    for y in range(text_rect.height):
        ratio = y / text_rect.height
        color = (
            int(color1[0] * (1 - ratio) + color2[0] * ratio),
            int(color1[1] * (1 - ratio) + color2[1] * ratio),
            int(color1[2] * (1 - ratio) + color2[2] * ratio)
        )
        pygame.draw.line(gradient, color, (0, y), (text_rect.width, y))
        
    gradient.blit(text_render, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)
    surface.blit(gradient, text_rect.topleft)

def draw_button(surface, rect, text, font, bg_color, text_color, border_radius=10):
    pygame.draw.rect(surface, bg_color, rect, border_radius=border_radius)
    text_render = font.render(text, True, text_color)
    text_rect = text_render.get_rect(center=rect.center)
    surface.blit(text_render, text_rect)

def draw_welcome_screen(surface, buttons, mouse_pos):
    overlay = pygame.Surface(surface.get_size(), pygame.SRCALPHA)
    overlay.fill((0, 0, 0, 180))
    surface.blit(overlay, (0,0))
    
    card_rect = pygame.Rect(0, 0, 450, 400)
    card_rect.center = surface.get_rect().center
    pygame.draw.rect(surface, GRAY_900, card_rect, border_radius=16)
    pygame.draw.rect(surface, GRAY_700, card_rect, border_radius=16, width=1)
    
    content_rect = card_rect.inflate(-60, -60)
    
    # Trophy icon at top
    if assets_loaded and 'trophy' in ui_assets:
        icon = ui_assets['trophy']
        icon_rect = icon.get_rect(midtop=(card_rect.centerx, content_rect.top))
        surface.blit(icon, icon_rect)

    y_offset = content_rect.top + 60
    draw_text(surface, "Welcome to", HEADER_FONT, GRAY_300, (card_rect.centerx, y_offset), align="center")
    
    y_offset += 40
    draw_text(surface, "Treasure Race!", TITLE_FONT, YELLOW_400, (card_rect.centerx, y_offset), align="center")
    
    y_offset += 60
    draw_text(surface, "Compete against AI to collect treasures", TEXT_FONT, GRAY_300, (card_rect.centerx, y_offset), align="center")
    
    y_offset += 25
    draw_text(surface, "and be the first to reach 100 points!", TEXT_FONT, GRAY_300, (card_rect.centerx, y_offset), align="center")
    
    # Buttons at bottom
    for name in ['welcome_start', 'welcome_instructions']:
        btn_rect = buttons[name]
        is_hovered = btn_rect.collidepoint(mouse_pos)
        text = "Start Game" if name == 'welcome_start' else "Instructions"
        
        color = PURPLE_700 if is_hovered else PURPLE_600
        if name == 'welcome_instructions':
            color = GRAY_800 if is_hovered else GRAY_700
        
        pygame.draw.rect(surface, color, btn_rect, border_radius=8)
        draw_text(surface, text, TEXT_FONT, WHITE, btn_rect.center, align="center", bold=True)

def draw_countdown(surface, number):
    # Create a subtle overlay for better contrast
    overlay = pygame.Surface(surface.get_size(), pygame.SRCALPHA)
    overlay.fill((0, 0, 0, 120))  # Reduced opacity for lighter feel
    surface.blit(overlay, (0, 0))
    
    if number > 0:
        # Create a pulsing effect
        pulse = (pygame.time.get_ticks() % 500) / 500.0
        scale = 1.0 + pulse * 0.2
        
        center = surface.get_rect().center
        
        # Create a unified rounded rectangle background for both texts
        bg_width = 280
        bg_height = 200
        bg_rect = pygame.Rect(0, 0, bg_width, bg_height)
        bg_rect.center = center
        
        # Draw the unified purple background with transparency
        purple_bg = (*PURPLE_700, 160)  # PURPLE_700 with transparency
        bg_surface = pygame.Surface((bg_width, bg_height), pygame.SRCALPHA)
        pygame.draw.rect(bg_surface, purple_bg, (0, 0, bg_width, bg_height), border_radius=20)
        surface.blit(bg_surface, bg_rect.topleft)
        
        # Countdown number
        countdown_font = pygame.font.Font(None, int(120 * scale))
        text = countdown_font.render(str(number), True, YELLOW_400)  # Changed to white for better contrast on purple
        text_rect = text.get_rect(center=(center[0], center[1] - 30))  # Moved up slightly
        
        # Add subtle shadow for readability
        shadow_offset = 2
        shadow_text = countdown_font.render(str(number), True, PURPLE_400)  # Darker purple shadow
        shadow_rect = text_rect.copy()
        shadow_rect.move_ip(shadow_offset, shadow_offset)
        surface.blit(shadow_text, shadow_rect)
        surface.blit(text, text_rect)
        
        # "Get Ready!" text
        ready_text = HEADER_FONT.render("Get Ready!", True, YELLOW_400)  # Changed to white
        ready_rect = ready_text.get_rect(center=(center[0], center[1] + 60))  # Positioned below number
        
        # Subtle shadow for "Get Ready!"
        shadow_ready = HEADER_FONT.render("Get Ready!", True, PURPLE_400)  # Darker purple shadow
        shadow_ready_rect = ready_rect.copy()
        shadow_ready_rect.move_ip(1, 1)
        surface.blit(shadow_ready, shadow_ready_rect)
        surface.blit(ready_text, ready_rect) 