import pygame
import sys
import random
from config import *
from board import Board
from player import Player
import ui
import Astar

class Game:
    def __init__(self, screen):
        self.screen = screen
        self.clock = pygame.time.Clock()
        self.first_launch = True  # Track if this is the first time the game is starting
        self.min_treasures = MIN_TREASURES_ON_BOARD  # Make it configurable
        self.initialize_game()

    def initialize_game(self, skip_welcome=False):
        # Show welcome screen only on first launch, unless explicitly skipped
        if self.first_launch and not skip_welcome:
            self.game_status = 'welcome'
            self.first_launch = False  # Set to False after first launch
        else:
            self.game_status = 'playing'
            
        self.show_instructions = False
        self.turn_count = 0
        self.winner = None
        self.p1_visual_score = 0
        self.p2_visual_score = 0
        
        # Countdown state variables
        self.countdown_active = False
        self.countdown_start_time = 0
        self.countdown_number = 3
        
        self.board_rect, self.sidebar_rect = ui.draw_main_layout(self.screen)
        
        self.board = Board(self.board_rect)
        self.player1 = Player(0, 0, is_human=True)
        self.player2 = Player(GRID_SIZE - 1, GRID_SIZE - 1, is_human=False)
        self.players = [self.player1, self.player2]
        
        # Ensure we start with enough treasures
        self.ensure_minimum_treasures()
        
        self.last_ai_move_time = pygame.time.get_ticks()
        self.last_respawn_check_time = pygame.time.get_ticks()

        # sidebar_content_rect = self.sidebar_rect.inflate(-20, -20)
        # sb_h = 280
        # ctrl_h = self.sidebar_rect.height - sb_h - 40
        # self.scoreboard_rect = pygame.Rect(sidebar_content_rect.x, sidebar_content_rect.y, sidebar_content_rect.width, sb_h)
        # self.controls_rect = pygame.Rect(sidebar_content_rect.x, self.scoreboard_rect.bottom + 20, sidebar_content_rect.width, ctrl_h)

        # Let UI calculate positions
        scoreboard_h = 280
        controls_h = self.sidebar_rect.height - scoreboard_h - 15
        self.scoreboard_rect = pygame.Rect(self.sidebar_rect.left, self.sidebar_rect.top, self.sidebar_rect.width, scoreboard_h)
        self.controls_rect = pygame.Rect(self.sidebar_rect.left, self.scoreboard_rect.bottom + 15, self.sidebar_rect.width, controls_h)

        self.buttons = self._define_buttons()

    def _define_buttons(self):
        buttons = {}
        # Remove the old pause_resume button from scoreboard
        sb_content = self.scoreboard_rect.inflate(-30, -30)
        buttons['freeze_ai'] = pygame.Rect(sb_content.right - 95, sb_content.top + 58, 95, 28)
        
        # Controls buttons - pause_resume is now calculated in draw function
        buttons['new_game'] = pygame.Rect(0,0,0,0)
        buttons['pause_resume'] = pygame.Rect(0,0,0,0)  # Moved from scoreboard to controls
        buttons['instructions'] = pygame.Rect(0,0,0,0)

        # Game Over buttons
        go_card_rect = pygame.Rect(0,0, 450, 450)
        go_card_rect.center = self.screen.get_rect().center
        go_content_rect = go_card_rect.inflate(-60, -60)
        
        btn_w_go, btn_h_go = (go_content_rect.width - 20) / 2, 50
        buttons_y = go_content_rect.bottom - btn_h_go
        buttons['game_over_restart'] = pygame.Rect(go_content_rect.left, buttons_y, btn_w_go, btn_h_go)
        buttons['game_over_end_game'] = pygame.Rect(go_content_rect.left + btn_w_go + 20, buttons_y, btn_w_go, btn_h_go)

        # Instructions buttons
        inst_card_rect = pygame.Rect(0, 0, 650, 600)
        inst_card_rect.center = self.screen.get_rect().center
        buttons['instructions_close'] = pygame.Rect(inst_card_rect.right - 40, inst_card_rect.top + 20, 20, 20)
        buttons['instructions_got_it'] = pygame.Rect(0,0,0,0)
        
        # Welcome screen buttons
        welcome_card_rect = pygame.Rect(0,0, 450, 400)
        welcome_card_rect.center = self.screen.get_rect().center
        welcome_content_rect = welcome_card_rect.inflate(-60, -60)
        
        btn_w_welcome, btn_h_welcome = (welcome_content_rect.width - 20) / 2, 50
        buttons_y = welcome_content_rect.bottom - btn_h_welcome
        buttons['welcome_start'] = pygame.Rect(welcome_content_rect.left, buttons_y, btn_w_welcome, btn_h_welcome)
        buttons['welcome_instructions'] = pygame.Rect(welcome_content_rect.left + btn_w_welcome + 20, buttons_y, btn_w_welcome, btn_h_welcome)
        
        return buttons

    def find_next_ai_move(self):
        # The pathfinding now automatically targets the best treasure
        # No need to manually find targets here
        p2_pos = (self.player2.x, self.player2.y)
        
        # Get path to best treasure (or fallback to current position if no treasures)
        path = Astar.a_star_pathfinding(p2_pos, p2_pos, self.board.grid)
        
        if path and len(path) > 1:
            return path[1]  # Next step
        
        return p2_pos

    def count_active_treasures(self):
        """Count the number of uncollected treasures on the board."""
        count = 0
        for row in self.board.grid:
            for cell in row:
                if isinstance(cell, dict) and cell.get('type') == 'treasure' and not cell.get('collected'):
                    count += 1
        return count

    def get_empty_cells(self):
        """Get all empty cells or cells with collected items."""
        empty_cells = []
        for y, row in enumerate(self.board.grid):
            for x, cell in enumerate(row):
                if cell == 'empty' or (isinstance(cell, dict) and cell.get('collected')):
                    empty_cells.append((x, y))
        return empty_cells

    def spawn_treasure_at_position(self, x, y):
        """Spawn a treasure at the specified position."""
        points = random.choice(TREASURE_POINTS)
        self.board.grid[y][x] = {'type': 'treasure', 'value': points, 'collected': False}

    def spawn_trap_at_position(self, x, y):
        """Spawn a trap at the specified position."""
        self.board.grid[y][x] = {'type': 'trap', 'value': TRAP_VALUE, 'collected': False}

    def ensure_minimum_treasures(self):
        """Ensure the board has at least the minimum number of treasures."""
        current_treasures = self.count_active_treasures()
        treasures_needed = max(0, self.min_treasures - current_treasures)
        
        if treasures_needed > 0:
            empty_cells = self.get_empty_cells()
            
            # Spawn the needed treasures
            for _ in range(min(treasures_needed, len(empty_cells))):
                if empty_cells:
                    x, y = random.choice(empty_cells)
                    empty_cells.remove((x, y))  # Remove to avoid duplicates
                    self.spawn_treasure_at_position(x, y)

    def handle_cell_interaction(self, player, pos):
        x, y = pos
        cell = self.board.grid[y][x]
        if isinstance(cell, dict) and not cell.get('collected'):
            player.change_score(cell['value'])
            cell['collected'] = True
            
            # Immediately check if we need to spawn more treasures
            if cell.get('type') == 'treasure':
                self.ensure_minimum_treasures()

    def respawn_item(self):
        """Legacy method - now replaced by ensure_minimum_treasures but kept for compatibility."""
        empty_cells = self.get_empty_cells()
        
        if empty_cells:
            x, y = random.choice(empty_cells)
            if random.random() < TREASURE_SPAWN_PROBABILITY:
                self.spawn_treasure_at_position(x, y)
            else:
                self.spawn_trap_at_position(x, y)

    def check_and_respawn_items(self):
        """Periodic check to ensure minimum treasures and spawn occasional traps."""
        RESPAWN_CHECK_INTERVAL = 2000  # Check every 2 seconds for traps
        now = pygame.time.get_ticks()

        if now - self.last_respawn_check_time > RESPAWN_CHECK_INTERVAL:
            self.last_respawn_check_time = now
            
            # Always ensure minimum treasures
            self.ensure_minimum_treasures()
            
            # Occasionally spawn traps for additional challenge
            if random.random() < 0.3:  # 30% chance to spawn a trap
                empty_cells = self.get_empty_cells()
                if empty_cells:
                    x, y = random.choice(empty_cells)
                    self.spawn_trap_at_position(x, y)

    def update(self):
        lerp_factor = 0.05
        self.p1_visual_score += (self.player1.score - self.p1_visual_score) * lerp_factor
        self.p2_visual_score += (self.player2.score - self.p2_visual_score) * lerp_factor

        # Handle countdown logic
        if self.countdown_active:
            current_time = pygame.time.get_ticks()
            elapsed = current_time - self.countdown_start_time
            
            if elapsed >= 1000:  # 1 second intervals
                self.countdown_number -= 1
                self.countdown_start_time = current_time
                
                if self.countdown_number <= 0:
                    self.countdown_active = False
                    self.game_status = 'playing'

        if self.game_status != 'playing':
            return
        
        now = pygame.time.get_ticks()
        if not self.player2.is_frozen and now - self.last_ai_move_time > AI_MOVE_INTERVAL:
            self.last_ai_move_time = now

            if self.player2.can_freeze() and not self.player1.is_frozen:
                # Enhanced strategic freezing logic
                treasures = []
                for y, row in enumerate(self.board.grid):
                    for x, cell in enumerate(row):
                        if isinstance(cell, dict) and cell.get('type') == 'treasure' and not cell.get('collected'):
                            treasures.append({'x': x, 'y': y, 'value': cell['value']})
                
                p1_pos = (self.player1.x, self.player1.y)
                p2_pos = (self.player2.x, self.player2.y)
                
                # Check if player is threatening AI's strategic goals
                should_freeze = False
                
                # 1. Check if player is close to high-value treasures
                for treasure in treasures:
                    t_pos = (treasure['x'], treasure['y'])
                    p1_distance = abs(t_pos[0] - p1_pos[0]) + abs(t_pos[1] - p1_pos[1])
                    p2_distance = abs(t_pos[0] - p2_pos[0]) + abs(t_pos[1] - p2_pos[1])
                    
                    # If player is closer to a valuable treasure, consider freezing
                    if (treasure['value'] >= 10 and p1_distance <= 2 and p1_distance < p2_distance):
                        should_freeze = True
                        break
                
                # 2. Check if player is on a treasure collection spree (multiple treasures nearby)
                if not should_freeze:
                    nearby_treasures = sum(1 for t in treasures 
                                         if abs(t['x'] - p1_pos[0]) + abs(t['y'] - p1_pos[1]) <= 3)
                    if nearby_treasures >= 3:  # Player has access to multiple treasures
                        should_freeze = True
                
                # 3. Check if player is ahead in score and close to winning
                if not should_freeze and self.player1.score > self.player2.score:
                    score_gap = self.player1.score - self.player2.score
                    if score_gap >= 20 or self.player1.score >= 80:  # Close to winning
                        should_freeze = True
                
                if should_freeze:
                    if self.player2.use_freeze():
                        self.player1.apply_freeze()

            next_pos = self.find_next_ai_move()
            if next_pos:
                self.player2.x, self.player2.y = next_pos
                self.handle_cell_interaction(self.player2, next_pos)

                # Update frozen player's remaining moves after AI moves
                if self.player1.is_frozen:
                    self.player1.frozen_moves_left -= 1
                    if self.player1.frozen_moves_left <= 0:
                        self.player1.is_frozen = False
        
        self.check_game_over()
        self.check_and_respawn_items()

    def check_game_over(self):
        if self.player1.score >= WINNING_SCORE:
            self.game_status = 'finished'
            self.winner = 'Player 1'
        elif self.player2.score >= WINNING_SCORE:
            self.game_status = 'finished'
            self.winner = 'Player 2 (AI)'

    def handle_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if self.show_instructions:
                ui.instructions_scroll_state.handle_event(event)
                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    pos = event.pos
                    if self.buttons['instructions_close'].collidepoint(pos) or self.buttons['instructions_got_it'].collidepoint(pos):
                        self.show_instructions = False
                        # If game was auto-paused when opening instructions, resume it
                        if self.game_status == 'paused':
                            self.game_status = 'playing'
                continue

            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                pos = event.pos

                if self.game_status == 'finished':
                    if self.buttons['game_over_restart'].collidepoint(pos): self.initialize_game(skip_welcome=True)
                    if self.buttons['game_over_end_game'].collidepoint(pos): 
                        pygame.quit()
                        sys.exit()
                    continue

                if self.game_status == 'welcome':
                    if self.buttons['welcome_start'].collidepoint(pos):
                        self.countdown_active = True
                        self.countdown_start_time = pygame.time.get_ticks()
                        self.countdown_number = 3
                        self.game_status = 'countdown'
                    if self.buttons['welcome_instructions'].collidepoint(pos):
                        self.show_instructions = True
                        ui.instructions_scroll_state.scroll_y = 0
                    continue

                # General buttons - removed home button logic
                if self.buttons['new_game'].collidepoint(pos): self.initialize_game(skip_welcome=True)
                if self.buttons['instructions'].collidepoint(pos):
                    self.show_instructions = True
                    ui.instructions_scroll_state.scroll_y = 0
                    # Auto-pause the game when opening instructions
                    if self.game_status == 'playing':
                        self.game_status = 'paused'

                if self.buttons['pause_resume'].collidepoint(pos):
                    self.game_status = 'playing' if self.game_status == 'paused' else 'paused'
                if self.buttons['freeze_ai'].collidepoint(pos):
                    if self.player1.can_freeze() and not self.player2.is_frozen:
                        if self.player1.use_freeze():
                            self.player2.apply_freeze()

            if event.type == pygame.KEYDOWN:
                # Space bar toggles pause/resume
                if event.key == pygame.K_SPACE:
                    self.game_status = 'playing' if self.game_status == 'paused' else 'paused'
                    continue

                # F key triggers freeze
                if event.key == pygame.K_f:
                    if self.player1.can_freeze() and not self.player2.is_frozen:
                        if self.player1.use_freeze():
                            self.player2.apply_freeze()
                    continue

                # Movement keys only work when game is playing
                if self.game_status != 'playing': 
                    continue

                moved = True
                if event.key == pygame.K_UP: self.player1.move(0, -1)
                elif event.key == pygame.K_DOWN: self.player1.move(0, 1)
                elif event.key == pygame.K_LEFT: self.player1.move(-1, 0)
                elif event.key == pygame.K_RIGHT: self.player1.move(1, 0)
                else: moved = False

                if moved and not self.player1.is_frozen:
                    if self.player2.is_frozen:
                        self.player2.frozen_moves_left -= 1
                        if self.player2.frozen_moves_left <= 0:
                            self.player2.is_frozen = False
                    
                    self.handle_cell_interaction(self.player1, (self.player1.x, self.player1.y))
                    if (self.player1.x, self.player1.y) == (self.player2.x, self.player2.y):
                        self.player1.change_score(-COLLISION_PENALTY)
                        self.player2.change_score(-COLLISION_PENALTY)

    def draw(self):
        ui.draw_background(self.screen)
        self.board_rect, self.sidebar_rect = ui.draw_main_layout(self.screen)
        
        mouse_pos = pygame.mouse.get_pos()
        self.board.draw(self.screen, self.players, mouse_pos)
        
        ui.draw_scoreboard(self.screen, self.scoreboard_rect, self.player1, self.player2, self.turn_count, self.p1_visual_score, self.p2_visual_score, self.game_status, self.buttons, mouse_pos)
        ui.draw_game_controls(self.screen, self.controls_rect, self.buttons, mouse_pos, self.game_status)

        if self.game_status == 'finished':
            ui.draw_game_over(self.screen, self.winner, self.player1.score, self.player2.score, self.buttons, mouse_pos)
        elif self.game_status == 'welcome':
            ui.draw_welcome_screen(self.screen, self.buttons, mouse_pos)
        elif self.game_status == 'countdown':
            ui.draw_countdown(self.screen, self.countdown_number)
        elif self.game_status == 'paused':
            overlay = pygame.Surface(self.screen.get_size(), pygame.SRCALPHA)
            overlay.fill((0, 0, 0, 150))
            self.screen.blit(overlay, (0, 0))
            font = pygame.font.Font(None, 80)
            text = font.render("Paused", True, ui.WHITE)
            text_rect = text.get_rect(center=self.screen.get_rect().center)
            self.screen.blit(text, text_rect)
        
        if self.show_instructions:
            ui.draw_instructions(self.screen, self.buttons, mouse_pos)

        pygame.display.flip()

    def run(self):
        while True:
            self.handle_events()
            self.update()
            self.draw()
            self.clock.tick() 