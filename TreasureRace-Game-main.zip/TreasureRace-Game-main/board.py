import pygame
import random
import math
from config import *
import ui as ui_module

# It's recommended to move these color definitions to config.py
GRAY_800 = (31, 41, 55)
GRAY_700 = (55, 65, 81)
BLUE_400 = (96, 165, 250)
BLUE_600 = (37, 99, 235)
GREEN_400 = (74, 222, 128)
GREEN_600 = (22, 163, 74)
P1_P2_MERGE_1 = (59, 130, 246)
P1_P2_MERGE_2 = (34, 197, 94)
YELLOW_400 = (250, 204, 21)
YELLOW_600 = (202, 138, 4)
ORANGE_400 = (251, 146, 60)
ORANGE_600 = (234, 88, 12)
PURPLE_400 = (192, 132, 252)
PURPLE_600 = (147, 51, 234)
RED_500 = (239, 68, 68)
RED_700 = (185, 28, 28)
CYAN_300 = (103, 232, 249)
WHITE = (255, 255, 255)

# Board layout constants
GAP_SIZE = 4
CELL_RADIUS = 8

class Board:
    def __init__(self, board_rect):
        self.board_rect = board_rect
        self.grid = self._create_grid()
        player_starts = [(0, 0), (GRID_SIZE - 1, GRID_SIZE - 1)]
        self._place_items('treasure', 10, player_starts)
        self._place_items('trap', 8, player_starts)
        
        self.assets_loaded = False
        self.cell_size, self.gap_size = self._calculate_layout()
        self._load_assets()
        self.font = pygame.font.Font(None, 20)
        
        self.gradient_cache = {}
        self._pre_render_gradients()

    def _calculate_layout(self):
        # Calculate cell size to fit inside board_rect
        max_width = self.board_rect.width / GRID_SIZE
        max_height = self.board_rect.height / GRID_SIZE
        cell_size = int(min(max_width, max_height) * 0.9)
        gap_size = int(cell_size * 0.1)
        return cell_size, gap_size

    def _load_assets(self):
        try:
            icon_size = (int(self.cell_size * 0.6), int(self.cell_size * 0.6))
            self.user_icon = pygame.transform.scale(pygame.image.load('assets/user-round.png').convert_alpha(), icon_size)
            self.bot_icon = pygame.transform.scale(pygame.image.load('assets/bot.png').convert_alpha(), icon_size)
            
            gem_zap_size = (int(self.cell_size * 0.5), int(self.cell_size * 0.5))
            self.gem_icon = pygame.transform.scale(pygame.image.load('assets/gem.png').convert_alpha(), gem_zap_size)
            self.zap_icon = pygame.transform.scale(pygame.image.load('assets/zap.png').convert_alpha(), gem_zap_size)

            snowflake_size = (int(self.cell_size * 0.3), int(self.cell_size * 0.3))
            self.snowflake_icon = pygame.transform.scale(pygame.image.load('assets/snowflake.png').convert_alpha(), snowflake_size)

            small_icon_size = (int(self.cell_size * 0.4), int(self.cell_size * 0.4))
            self.small_user_icon = pygame.transform.scale(self.user_icon, small_icon_size)
            self.small_bot_icon = pygame.transform.scale(self.bot_icon, small_icon_size)
            self.assets_loaded = True
        except (pygame.error, FileNotFoundError) as e:
            print(f"Warning: Could not load assets. Using fallback shapes. Error: {e}")
            print("To see icons, create an 'assets' folder with: user-round.png, bot.png, gem.png, zap.png, snowflake.png")

    def _create_gradient_surface(self, size, start_color, end_color):
        surface = pygame.Surface(size).convert_alpha()
        start_rgb = pygame.Color(start_color)
        end_rgb = pygame.Color(end_color)
        for y in range(size[1]):
            for x in range(size[0]):
                blend = (x + y) / (size[0] + size[1])
                color = start_rgb.lerp(end_rgb, blend)
                surface.set_at((x, y), color)
        return surface

    def _pre_render_gradients(self):
        size = (self.cell_size, self.cell_size)
        self.gradient_cache['player1'] = self._create_gradient_surface(size, ui_module.P1_COLOR, ui_module.BLUE_600)
        self.gradient_cache['player2'] = self._create_gradient_surface(size, ui_module.P2_COLOR, ui_module.GREEN_600)
        self.gradient_cache['merge'] = self._create_gradient_surface(size, (59, 130, 246), (34, 197, 94))
        self.gradient_cache['treasure_5'] = self._create_gradient_surface(size, ui_module.YELLOW_400, ui_module.YELLOW_600)
        self.gradient_cache['treasure_10'] = self._create_gradient_surface(size, ui_module.ORANGE_400, ui_module.ORANGE_600)
        self.gradient_cache['treasure_15'] = self._create_gradient_surface(size, ui_module.PURPLE_400, ui_module.PURPLE_600)
        self.gradient_cache['trap'] = self._create_gradient_surface(size, ui_module.TRAP_COLOR, ui_module.RED_700)

    def _create_grid(self):
        return [['empty' for _ in range(GRID_SIZE)] for _ in range(GRID_SIZE)]

    def _place_items(self, item_type, count, exclude_positions=[]):
        """Place items on the board, ensuring minimum treasure count."""
        placed = 0
        attempts = 0
        max_attempts = count * 10  # Prevent infinite loops
        
        while placed < count and attempts < max_attempts:
            attempts += 1
            x = random.randint(0, GRID_SIZE - 1)
            y = random.randint(0, GRID_SIZE - 1)
            
            if self.grid[y][x] == 'empty' and (x, y) not in exclude_positions:
                if item_type == 'treasure':
                    points = random.choice(TREASURE_POINTS)
                    self.grid[y][x] = {'type': 'treasure', 'value': points, 'collected': False}
                elif item_type == 'trap':
                    self.grid[y][x] = {'type': 'trap', 'value': TRAP_VALUE, 'collected': False}
                placed += 1

    def get_cell_rect(self, x, y):
        total_grid_width = GRID_SIZE * (self.cell_size + self.gap_size) - self.gap_size
        total_grid_height = GRID_SIZE * (self.cell_size + self.gap_size) - self.gap_size
        offset_x = self.board_rect.left + (self.board_rect.width - total_grid_width) / 2
        offset_y = self.board_rect.top + (self.board_rect.height - total_grid_height) / 2

        top_left_x = offset_x + x * (self.cell_size + self.gap_size)
        top_left_y = offset_y + y * (self.cell_size + self.gap_size)
        return pygame.Rect(top_left_x, top_left_y, self.cell_size, self.cell_size)

    def _draw_pulsing_overlay(self, screen, rect, period=2000):
        alpha = (math.sin(pygame.time.get_ticks() * 2 * math.pi / period) + 1) / 2 * 60
        overlay = pygame.Surface(rect.size, pygame.SRCALPHA)
        overlay.fill((255, 255, 255, alpha))
        screen.blit(overlay, rect.topleft)
        
    def _draw_fallback_icon(self, screen, rect, icon_type):
        if icon_type == 'user':
            pygame.draw.circle(screen, WHITE, rect.center, self.cell_size * 0.25, 2)
        elif icon_type == 'bot':
            pygame.draw.rect(screen, WHITE, (rect.centerx - self.cell_size * 0.2, rect.centery - self.cell_size * 0.2, self.cell_size * 0.4, self.cell_size * 0.4), 2)
        elif icon_type == 'gem':
            points = [rect.midtop, (rect.right - 5, rect.centery), rect.midbottom, (rect.left + 5, rect.centery)]
            pygame.draw.polygon(screen, WHITE, points, 2)
        elif icon_type == 'zap':
            points = [(rect.centerx + 5, rect.top + 5), (rect.centerx - 5, rect.centery), (rect.centerx + 5, rect.centery), (rect.centerx - 5, rect.bottom - 5)]
            pygame.draw.lines(screen, WHITE, False, points, 3)
        elif icon_type == 'merge':
            pygame.draw.circle(screen, WHITE, (rect.centerx - self.cell_size * 0.15, rect.centery), self.cell_size * 0.18, 2)
            pygame.draw.rect(screen, WHITE, (rect.centerx + self.cell_size * 0.03, rect.centery - self.cell_size * 0.18, self.cell_size * 0.3, self.cell_size * 0.3), 2)
        elif icon_type == 'snowflake':
            center = (rect.right - 8, rect.top + 8)
            pygame.draw.line(screen, CYAN_300, (center[0] - 5, center[1]), (center[0] + 5, center[1]), 2)
            pygame.draw.line(screen, CYAN_300, (center[0], center[1] - 5), (center[0], center[1] + 5), 2)
            pygame.draw.line(screen, CYAN_300, (center[0] - 3, center[1] - 3), (center[0] + 3, center[1] + 3), 2)
            pygame.draw.line(screen, CYAN_300, (center[0] + 3, center[1] - 3), (center[0] - 3, center[1] + 3), 2)

    def draw(self, screen, players, mouse_pos):
        p1, p2 = players
        p1_pos = (p1.x, p1.y)
        p2_pos = (p2.x, p2.y)
        
        for y in range(GRID_SIZE):
            for x in range(GRID_SIZE):
                rect = self.get_cell_rect(x, y)
                is_hovered = rect.collidepoint(mouse_pos)
                
                # Draw base cell
                base_color = GRAY_700 if is_hovered else GRAY_800
                pygame.draw.rect(screen, base_color, rect, border_radius=CELL_RADIUS)
                pygame.draw.rect(screen, BLACK, rect, 1, border_radius=CELL_RADIUS)
                
                cell_content = self.grid[y][x]
                pos = (x, y)
                
                is_p1_here = (pos == p1_pos)
                is_p2_here = (pos == p2_pos)
                
                content_surf = None
                icon_type = None
                
                if isinstance(cell_content, dict) and not cell_content['collected']:
                    if cell_content['type'] == 'treasure':
                        points = cell_content['value']
                        content_surf = self.gradient_cache[f'treasure_{points}']
                        icon_type = 'gem'
                        self._draw_pulsing_overlay(screen, rect)
                    elif cell_content['type'] == 'trap':
                        content_surf = self.gradient_cache['trap']
                        icon_type = 'zap'

                if is_p1_here and is_p2_here:
                    content_surf = self.gradient_cache['merge']
                    self._draw_pulsing_overlay(screen, rect, period=1000)
                    icon_type = 'merge'
                elif is_p1_here:
                    content_surf = self.gradient_cache['player1']
                    icon_type = 'user'
                elif is_p2_here:
                    content_surf = self.gradient_cache['player2']
                    icon_type = 'bot'

                if content_surf:
                    screen.blit(content_surf, rect.topleft)

                # Draw icons first
                if self.assets_loaded:
                    icon = None
                    if icon_type == 'user': icon = self.user_icon
                    elif icon_type == 'bot': icon = self.bot_icon
                    elif icon_type == 'gem': icon = self.gem_icon
                    elif icon_type == 'zap': icon = self.zap_icon
                    
                    if icon_type == 'merge':
                        user_rect = self.small_user_icon.get_rect(center=(rect.centerx - self.cell_size * 0.15, rect.centery))
                        bot_rect = self.small_bot_icon.get_rect(center=(rect.centerx + self.cell_size * 0.15, rect.centery))
                        screen.blit(self.small_user_icon, user_rect)
                        screen.blit(self.small_bot_icon, bot_rect)
                    elif icon:
                        icon_rect = icon.get_rect(center=rect.center)
                        screen.blit(icon, icon_rect)
                elif icon_type:
                    self._draw_fallback_icon(screen, rect, icon_type)

                # Draw labels AFTER icons so they appear on top
                if isinstance(cell_content, dict) and not cell_content['collected']:
                    if cell_content['type'] == 'treasure':
                        points = cell_content['value']
                        # Display "+X" label in bottom-right corner
                        text_surf = self.font.render(f"+{points}", True, WHITE)
                        text_bg = pygame.Surface((text_surf.get_width() + 6, text_surf.get_height() + 4), pygame.SRCALPHA)
                        text_bg.fill((0, 0, 0, 128))
                        text_bg.blit(text_surf, (3, 2))
                        screen.blit(text_bg, (rect.right - text_bg.get_width() - 2, rect.bottom - text_bg.get_height() - 2))
                        
                    elif cell_content['type'] == 'trap':
                        # Display "-X" label for traps too for consistency
                        text_surf = self.font.render(f"{TRAP_VALUE}", True, WHITE)  # TRAP_VALUE is already negative
                        text_bg = pygame.Surface((text_surf.get_width() + 6, text_surf.get_height() + 4), pygame.SRCALPHA)
                        text_bg.fill((0, 0, 0, 128))
                        text_bg.blit(text_surf, (3, 2))
                        screen.blit(text_bg, (rect.right - text_bg.get_width() - 2, rect.bottom - text_bg.get_height() - 2))

                if (is_p1_here and p1.is_frozen) or (is_p2_here and p2.is_frozen):
                    if self.assets_loaded:
                        angle = (pygame.time.get_ticks() / 10) % 360
                        rotated_icon = pygame.transform.rotate(self.snowflake_icon, angle)
                        icon_rect = rotated_icon.get_rect(center=(rect.right - 8, rect.top + 8))
                        screen.blit(rotated_icon, icon_rect)
                    else:
                        self._draw_fallback_icon(screen, rect, 'snowflake') 