# Screen dimensions
SCREEN_WIDTH = 900
SCREEN_HEIGHT = 700
GRID_WIDTH = 600
GRID_HEIGHT = 600
GRID_SIZE = 10
CELL_SIZE = 50
RIGHT_PANEL_WIDTH = SCREEN_WIDTH - GRID_WIDTH

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)

DARK_PURPLE = (48, 25, 52)
LIGHT_PURPLE = (90, 60, 100)
YELLOW = (255, 255, 0)
ORANGE = (255, 165, 0)
PURPLE = (128, 0, 128)
DARK_GRAY = (40, 40, 40)
LIGHT_BLUE = (173, 216, 230)

# Fonts
TITLE_FONT_SIZE = 74
SUBTITLE_FONT_SIZE = 24
PANEL_TITLE_FONT_SIZE = 36
SCORE_FONT_SIZE = 30
BUTTON_FONT_SIZE = 24
RULES_FONT_SIZE = 18

# Game settings
WINNING_SCORE = 100
TREASURE_POINTS = [5, 10, 15]
TRAP_VALUE = -10
COLLISION_PENALTY = 5
FREEZE_DURATION = 3
FREEZE_COOLDOWN = 10
AI_MOVE_INTERVAL = 500 # milliseconds

# Treasure spawning settings
MIN_TREASURES_ON_BOARD = 5  # Configurable threshold for minimum treasures
TREASURE_SPAWN_PROBABILITY = 0.7  # Probability of spawning treasure vs trap when respawning

# Treasure colors - mapping points to a dictionary for more data
TREASURES = {
    5: {'color': (250, 204, 21)},    # Yellow
    10: {'color': (251, 146, 60)},   # Orange
    15: {'color': (192, 132, 252)},  # Purple
} 