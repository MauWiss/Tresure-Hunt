import heapq
from typing import List, Tuple, Dict, Set, Optional


# ============================================================================
# CORE A* PATHFINDING MODULE
# ============================================================================

def heuristic(a: Tuple[int, int], b: Tuple[int, int]) -> float:
    """Manhattan distance heuristic for grid-based pathfinding."""
    return abs(a[0] - b[0]) + abs(a[1] - b[1])

def get_neighbors(pos: Tuple[int, int], grid: List[List]) -> List[Tuple[int, int]]:
    """Get valid neighboring positions for a given position."""
    x, y = pos
    neighbors = []
    
    # Check all 4 directions (no diagonals - maintains heuristic consistency)
    for dx, dy in [(0, 1), (1, 0), (0, -1), (-1, 0)]:
        nx, ny = x + dx, y + dy
        
        # Check bounds
        if 0 <= nx < len(grid[0]) and 0 <= ny < len(grid):
            # Check if cell is passable (not a wall or obstacle)
            cell = grid[ny][nx]
            if cell == 'empty' or isinstance(cell, dict):
                neighbors.append((nx, ny))
    
    return neighbors

def reconstruct_path(came_from: Dict[Tuple[int, int], Tuple[int, int]], 
                    current: Tuple[int, int]) -> List[Tuple[int, int]]:
    """Reconstruct the path from start to goal using the came_from dictionary."""
    path = [current]
    while current in came_from:
        current = came_from[current]
        path.append(current)
    return path[::-1]  # Reverse to get start-to-goal path

def astar(start: Tuple[int, int], goal: Tuple[int, int], 
          grid: List[List]) -> Optional[List[Tuple[int, int]]]:
    """
    Core A* pathfinding algorithm.
    
    Args:
        start: Starting position (x, y)
        goal: Goal position (x, y)
        grid: 2D grid where cells are either 'empty' or dict objects
        
    Returns:
        List of positions from start to goal, or None if no path exists
    """
    if start == goal:
        return [start]
    
    # Priority queue: (f_score, position)
    open_heap = [(0, start)]
    
    # Sets for efficient membership testing
    open_set: Set[Tuple[int, int]] = {start}
    closed_set: Set[Tuple[int, int]] = set()
    
    # Cost tracking
    came_from: Dict[Tuple[int, int], Tuple[int, int]] = {}
    g_score: Dict[Tuple[int, int], float] = {start: 0}
    f_score: Dict[Tuple[int, int], float] = {start: heuristic(start, goal)}
    
    while open_heap:
        current_f, current = heapq.heappop(open_heap)
        
        # Skip outdated entries (better path already found)
        if current in closed_set or current_f > f_score.get(current, float('inf')):
            continue
            
        # Remove from open set and add to closed set
        open_set.discard(current)
        closed_set.add(current)
        
        # Check if we reached the goal
        if current == goal:
            return reconstruct_path(came_from, current)
        
        # Examine all neighbors
        for neighbor in get_neighbors(current, grid):
            # Skip already fully explored nodes
            if neighbor in closed_set:
                continue
                
            tentative_g = g_score[current] + 1  # Uniform cost of 1 per step
            
            # If this is a better path to the neighbor
            if neighbor not in g_score or tentative_g < g_score[neighbor]:
                came_from[neighbor] = current
                g_score[neighbor] = tentative_g
                f_score[neighbor] = tentative_g + heuristic(neighbor, goal)
                
                # Always push the updated neighbor (handles duplicates correctly)
                heapq.heappush(open_heap, (f_score[neighbor], neighbor))
                open_set.add(neighbor)
    
    # No path found
    return None


# ============================================================================
# STRATEGIC TREASURE COLLECTION MODULE
# ============================================================================

def get_uncollected_treasures(grid: List[List]) -> List[Dict]:
    """
    Get all uncollected treasures from the grid with their positions and values.
    
    Returns:
        List of treasure dictionaries with 'x', 'y', 'value' keys
    """
    treasures = []
    for y, row in enumerate(grid):
        for x, cell in enumerate(row):
            if isinstance(cell, dict) and cell.get('type') == 'treasure' and not cell.get('collected', False):
                treasures.append({
                    'x': x,
                    'y': y,
                    'value': cell['value'],
                    'pos': (x, y)
                })
    return treasures

def calculate_treasure_route_value(start: Tuple[int, int], treasures: List[Dict], max_detour: int = 3) -> Tuple[List[Tuple[int, int]], int]:
    """
    Calculate the most valuable route that can collect multiple treasures efficiently.
    
    Args:
        start: Starting position
        treasures: List of available treasures
        max_detour: Maximum extra distance allowed for collecting additional treasures
        
    Returns:
        Tuple of (optimal_route, total_value)
    """
    if not treasures:
        return [], 0
    
    best_route = []
    best_value = 0
    
    # Try different combinations of treasures, starting with the most valuable
    treasures_by_value = sorted(treasures, key=lambda t: t['value'], reverse=True)
    
    # For each treasure as a primary target
    for primary_treasure in treasures_by_value:
        route = [primary_treasure['pos']]
        total_value = primary_treasure['value']
        
        # Calculate base distance to primary treasure
        base_distance = heuristic(start, primary_treasure['pos'])
        
        # Look for treasures that can be collected along the way or with minimal detour
        remaining_treasures = [t for t in treasures if t != primary_treasure]
        
        # Build an efficient multi-treasure route
        while remaining_treasures:
            best_addition = None
            best_efficiency = -float('inf')
            
            for treasure in remaining_treasures:
                # Calculate the efficiency of adding this treasure to the route
                if not route:
                    continue
                    
                last_pos = route[-1]
                detour_cost = heuristic(start, treasure['pos']) + heuristic(treasure['pos'], primary_treasure['pos']) - heuristic(start, primary_treasure['pos'])
                
                # Only consider if detour is reasonable
                if detour_cost <= max_detour:
                    efficiency = treasure['value'] / max(1, detour_cost)
                    if efficiency > best_efficiency:
                        best_efficiency = efficiency
                        best_addition = treasure
            
            if best_addition:
                # Insert the treasure in the optimal position in the route
                route.insert(-1, best_addition['pos'])  # Insert before the primary target
                total_value += best_addition['value']
                remaining_treasures.remove(best_addition)
            else:
                break
        
        # Calculate route efficiency (value per distance)
        route_distance = 0
        pos = start
        for waypoint in route:
            route_distance += heuristic(pos, waypoint)
            pos = waypoint
        
        route_efficiency = total_value / max(1, route_distance)
        
        # Update best route if this one is better
        if route_efficiency > best_value or (route_efficiency == best_value and total_value > sum(t['value'] for t in treasures if t['pos'] in best_route)):
            best_route = route
            best_value = route_efficiency
    
    return best_route, int(sum(t['value'] for t in treasures if t['pos'] in best_route))

def find_strategic_treasure_target(current_pos: Tuple[int, int], grid: List[List]) -> Optional[Tuple[int, int]]:
    """
    Find the best strategic target considering multi-treasure collection opportunities.
    """
    treasures = get_uncollected_treasures(grid)
    
    if not treasures:
        return None
    
    # Get the optimal multi-treasure route
    route, total_value = calculate_treasure_route_value(current_pos, treasures)
    
    if route:
        return route[0]  # Return the first treasure in the optimal route
    
    # Fallback to simple closest valuable treasure
    best_treasure = None
    best_score = -float('inf')
    
    for treasure in treasures:
        treasure_pos = treasure['pos']
        distance = heuristic(current_pos, treasure_pos)
        score = treasure['value'] - distance * 0.3  # Slightly favor closer treasures
        
        if score > best_score:
            best_score = score
            best_treasure = treasure_pos
    
    return best_treasure


# ============================================================================
# STRATEGIC AI PATHFINDER CLASS
# ============================================================================

class StrategicAIPathfinder:
    """
    Advanced pathfinder with strategic multi-treasure collection.
    Maintains route planning and caching separate from core A*.
    """
    
    def __init__(self):
        self.cached_paths: Dict[Tuple, List[Tuple[int, int]]] = {}
        self.grid_hash: Optional[int] = None
        self.current_route: List[Tuple[int, int]] = []
        self.route_index: int = 0
    
    def _hash_grid(self, grid: List[List]) -> int:
        """Create a hash of the grid state for cache invalidation."""
        grid_str = ""
        for row in grid:
            for cell in row:
                if cell == 'empty':
                    grid_str += "0"
                elif isinstance(cell, dict):
                    if cell.get('collected', False):
                        grid_str += "0"
                    else:
                        grid_str += f"{cell.get('type', 'x')}{cell.get('value', 0)}"
                else:
                    grid_str += "1"
        return hash(grid_str)
    
    def find_strategic_path(self, start: Tuple[int, int], 
                           grid: List[List], 
                           fallback_goal: Optional[Tuple[int, int]] = None) -> Optional[List[Tuple[int, int]]]:
        """
        Find a strategic path that considers multi-treasure collection.
        """
        current_hash = self._hash_grid(grid)
        
        # Check if we need to recalculate the route
        should_recalculate = (
            self.grid_hash != current_hash or  # Grid changed
            not self.current_route or  # No current route
            self.route_index >= len(self.current_route)  # Route completed
        )
        
        if should_recalculate:
            self._recalculate_strategic_route(start, grid)
            self.grid_hash = current_hash
        
        # If we have a strategic route, follow it
        if self.current_route and self.route_index < len(self.current_route):
            target = self.current_route[self.route_index]
            
            # Check if we've reached the current target
            if start == target:
                self.route_index += 1
                if self.route_index < len(self.current_route):
                    target = self.current_route[self.route_index]
                else:
                    # Route completed, recalculate
                    self._recalculate_strategic_route(start, grid)
                    if self.current_route:
                        target = self.current_route[0]
                    else:
                        return None
            
            # Find path to current target using core A*
            path = self._find_cached_path(start, target, grid)
            return path
        
        # Fallback behavior
        if fallback_goal:
            return self._find_cached_path(start, fallback_goal, grid)
        
        return None
    
    def _recalculate_strategic_route(self, start: Tuple[int, int], grid: List[List]):
        """Recalculate the strategic multi-treasure route."""
        treasures = get_uncollected_treasures(grid)
        route, _ = calculate_treasure_route_value(start, treasures, max_detour=4)
        
        self.current_route = route
        self.route_index = 0
        
        # Also consider opportunistic collection of nearby treasures
        if route:
            self._optimize_route_for_opportunities(start, grid)
    
    def _optimize_route_for_opportunities(self, start: Tuple[int, int], grid: List[List]):
        """Look for opportunities to collect additional treasures with minimal detour."""
        if not self.current_route:
            return
        
        treasures = get_uncollected_treasures(grid)
        route_treasures = set(self.current_route)
        nearby_treasures = [t for t in treasures if t['pos'] not in route_treasures]
        
        # Check each segment of the route for nearby treasures
        optimized_route = []
        current_pos = start
        
        for target in self.current_route:
            # Look for treasures near this segment
            for treasure in nearby_treasures:
                treasure_pos = treasure['pos']
                
                # Check if treasure is close to the path
                detour_distance = (heuristic(current_pos, treasure_pos) + 
                                 heuristic(treasure_pos, target) - 
                                 heuristic(current_pos, target))
                
                # If it's a small detour for a valuable treasure, add it
                if detour_distance <= 2 and treasure['value'] >= 10:
                    optimized_route.append(treasure_pos)
                    nearby_treasures.remove(treasure)
                    break
            
            optimized_route.append(target)
            current_pos = target
        
        self.current_route = optimized_route
    
    def _find_cached_path(self, start: Tuple[int, int], goal: Tuple[int, int], 
                         grid: List[List]) -> Optional[List[Tuple[int, int]]]:
        """Find path using core A* with caching."""
        # Check cache first
        cache_key = (start, goal, self.grid_hash)
        if cache_key in self.cached_paths:
            return self.cached_paths[cache_key]
        
        # Use core A* algorithm
        path = astar(start, goal, grid)
        
        # Cache the result
        self.cached_paths[cache_key] = path
        return path
    
    def clear_cache(self):
        """Clear the pathfinding cache and reset strategic planning."""
        self.cached_paths.clear()
        self.grid_hash = None
        self.current_route = []
        self.route_index = 0


# ============================================================================
# PUBLIC API
# ============================================================================

# Global strategic pathfinder instance
_strategic_pathfinder = StrategicAIPathfinder()

def a_star_pathfinding(start: Tuple[int, int], goal: Tuple[int, int], 
                      grid: List[List]) -> Optional[List[Tuple[int, int]]]:
    """
    Strategic A* pathfinding that considers multi-treasure collection.
    
    This is the main entry point used by the game.
    """
    return _strategic_pathfinder.find_strategic_path(start, grid, goal)

def get_ai_strategic_info(current_pos: Tuple[int, int], grid: List[List]) -> Dict:
    """
    Get information about the AI's current strategic thinking.
    Useful for debugging or displaying AI intentions.
    """
    treasures = get_uncollected_treasures(grid)
    route, total_value = calculate_treasure_route_value(current_pos, treasures)
    
    return {
        'current_route': _strategic_pathfinder.current_route,
        'route_index': _strategic_pathfinder.route_index,
        'available_treasures': len(treasures),
        'planned_value': total_value,
        'next_targets': route[:3] if route else []  # Next 3 targets
    }

def clear_pathfinding_cache():
    """Clear the pathfinding cache and reset strategic planning."""
    _strategic_pathfinder.clear_cache() 