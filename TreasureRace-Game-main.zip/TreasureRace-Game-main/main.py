import pygame
from config import *
from game import Game
import ui
import os


def main():
    pygame.init()
    # Load and play background music
    music_path = os.path.join('assets', 'sounds', 'background.mp3')
    if os.path.exists(music_path):
        try:
            pygame.mixer.init()
            pygame.mixer.music.load(music_path)
            pygame.mixer.music.play(-1)  # Loop indefinitely
        except Exception as e:
            print(f"Warning: Could not play background music: {e}")
    else:
        print(f"Background music file not found at {music_path}. No music will play.")

    screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
    pygame.display.set_caption("Treasure Race")
    ui.load_ui_assets()

    game = Game(screen)
    game.run()

if __name__ == '__main__' :
    main() 